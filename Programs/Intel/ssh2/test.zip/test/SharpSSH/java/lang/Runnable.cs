using System;

namespace SharpSsh.java.lang
{
	/// <summary>
	/// Summary description for Runnable.
	/// </summary>
	public interface Runnable
	{
		void run();
	}
}
