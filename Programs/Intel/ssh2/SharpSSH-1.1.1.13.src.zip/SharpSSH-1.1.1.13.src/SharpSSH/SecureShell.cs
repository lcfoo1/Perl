using System;

namespace Tamir.SharpSsh
{
	/// <summary>
	/// Summary description for SecureShell.
	/// </summary>
	public class SecureShell
	{
		public SecureShell()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
