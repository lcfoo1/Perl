using System;

namespace Tamir.SharpSsh.java.lang
{
	/// <summary>
	/// Summary description for Runnable.
	/// </summary>
	public interface Runnable
	{
		void run();
	}
}
