using System;

namespace Tamir.SharpSsh.java
{
	/// <summary>
	/// Summary description for RuntimeException.
	/// </summary>
	public class RuntimeException : Exception
	{
		public RuntimeException()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
