vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Mar 2006 11:19:23 -0000
vti_extenderversion:SR|4.0.2.7802
vti_backlinkinfo:VX|oop.htm
